import { useState } from "react";
import "./App.scss";

function App() {
  const str1 = "text1";
  const str2 = "text1";
  const name = "user";
  const age = "30";
  const arr = [1,2,3,4,5];
  const obj = {name: 'john', surname: 'smit'};
  const attr = "block";
  const li1 = <li>text1</li>;
	const li2 = <li>text2</li>;
	const li3 = <li>text3</li>;
  const [count, setCount] = useState(0);
  const increment = () => {
    setCount(count + 1);
  }
  const dicrement = () => {
    setCount(count - 1);
  }

  return (
    <>
      <div id={attr}  className="container">
        <p className="text-count">{count}</p>
        <button className="button" onClick={increment}>+1</button>
        <button className="button" onClick={dicrement}>-1</button>
        <p className="text1">текст</p>
        <p className="text2">текст</p>
        <input />
        <input /><input /><input />
        <p>{str1}</p>
        <p>{str2}</p>
        <p>name:{name}</p>
        <p>age:{age}</p>
        <ul>
          <li>{arr[0]}</li>
          <li>{arr[1]}</li>
          <li>{arr[2]}</li>
          <li>{arr[3]}</li>
          <li>{arr[4]}</li>
        </ul>
        <p>name:<span>{obj.name}</span><br/>surname:<span>{obj.surname}</span></p>
        <ul>
          <li>{li1}</li>
          <li>{li2}</li>
          <li>{li3}</li>
        </ul>
      </div >
        <div className="container">
          <ul>
            <li>1</li>
            <li>1</li>
            <li>1</li>
            <li>1</li>
            <li>1</li>
            <li>1</li>
            <li>1</li>
            <li>1</li>
            <li>1</li>
          </ul>
        </div>
    </>
  );
}

export default App;
